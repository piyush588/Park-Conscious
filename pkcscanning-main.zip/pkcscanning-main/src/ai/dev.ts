import { config } from 'dotenv';
config();

import '@/ai/flows/initiate-scan-with-prompt.ts';
import '@/ai/flows/summarize-scan-history.ts';
