import { ScannerLayout } from '@/components/scanner-layout';

export default function Home() {
  return <ScannerLayout />;
}
